import { CdzBudget } from '../types/task';

export const CDZ_LIST: CdzBudget[] = [
  {
    cdzEmail: 'abdelmajid.chouchene@vilavi.tn',
    nom: 'Abdelmajid Chouchene',
    aliases: ['CHOUCHENE ABDELMAJID', 'ABDELMAJID CHOUCHENE', 'CHOUCHENE'],
    zone: 'KEF - SILIANA - KASSERINE - SIDI BOUZID - GAFSA',
    budgetHabillageHt: 15000,
    budgetCadeauTtc: 20000,
    superviseurs: [
      { nom: 'KOUKI ANIS', email: 'anis.kouki@vilavi.tn' },
      { nom: 'ARWA WAJIH_BIS', email: 'wajih.arwa@vilavi.tn' },
      { nom: 'CHOUCHENE ABDELMAJID', email: 'abdelmajid.chouchene@vilavi.tn' },
      { nom: 'AMDOUNI AYMEN_BIS', email: 'aymen.amdouni@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'debeghi.lotfi@vilavi.tn',
    nom: 'Lotfi Debeghi',
    aliases: ['DABEGHI LOTFI', 'LOTFI DABEGHI', 'DEBEGHI LOTFI', 'LOTFI DEBEGHI'],
    zone: 'GABÈS - KÉBILI - TATAOUINE - MÉDENINE',
    budgetHabillageHt: 35000,
    budgetCadeauTtc: 40000,
    superviseurs: [
      { nom: 'REBAH MOHAMED', email: 'mohamed.rebah@vilavi.tn' },
      { nom: 'BEN MANSOUR MAHER', email: 'maher.benmansour@vilavi.tn' },
      { nom: 'DABEGHI LOTFI', email: 'debeghi.lotfi@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'sami.ez@vilavi.tn',
    nom: 'Sami Ezzar',
    aliases: ['SAMI EZZAR', 'EZZAR SAMI', 'SAMI EZ'],
    zone: 'SAHEL',
    budgetHabillageHt: 50000,
    budgetCadeauTtc: 60000,
    superviseurs: [
      { nom: 'MAHER AYEB', email: 'maher.ayeb@vilavi.tn' },
      { nom: 'AMARA MOHAMED AHMED', email: 'ahmed.amara@vilavi.tn' },
      { nom: 'MILED HAMZA', email: 'hamza.miled@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'tarak.boukottaya@vilavi.tn',
    nom: 'Tarak Boukottaya',
    aliases: ['BOUKOTTAYA TARAK', 'TARAK BOUKOTTAYA', 'BOUKOTTAYA', 'TARAK BOUKATAYA'],
    zone: 'SFAX',
    budgetHabillageHt: 20000,
    budgetCadeauTtc: 25000,
    superviseurs: [
      { nom: 'HRICHI OMAR', email: 'omar.hrichi@vilavi.tn' },
      { nom: 'ARWA WAJIH', email: 'wajih.arwa@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'fahmi.soudani@vilavi.tn',
    nom: 'Fahmi Soudani',
    aliases: ['SOUDANI FAHMI', 'FAHMI SOUDANI', 'SOUDANI'],
    zone: 'CAP BON',
    budgetHabillageHt: 30000,
    budgetCadeauTtc: 40000,
    superviseurs: [
      { nom: 'WAJDI KALAII', email: 'abdelhakim.hmem@vilavi.tn' },
      { nom: 'AHMED TRABELSI_BIS', email: 'ahmed.trabelsi@vilavi.tn' },
      { nom: 'SOUDANI FAHMI', email: 'fahmi.soudani@vilavi.tn' },
      { nom: 'SAIF AYARI_BIS', email: 'saif.ayari@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'mohamed.jouini@vilavi.tn',
    nom: 'Mohamed Jouini',
    aliases: ['JOUINI MOHAMED', 'MOHAMED JOUINI', 'JOUINI'],
    zone: 'Jendouba - Béja - Tunis - Ben Arous',
    budgetHabillageHt: 40000,
    budgetCadeauTtc: 60000,
    superviseurs: [
      { nom: 'AMDOUNI AYMEN', email: 'aymen.amdouni@vilavi.tn' },
      { nom: 'AHMED TRABELSI', email: 'ahmed.trabelsi@vilavi.tn' },
      { nom: 'ZGHIDI CHOKRI', email: 'chokri.zghidi@vilavi.tn' },
      { nom: 'SAIF AYARI', email: 'saif.ayari@vilavi.tn' },
      { nom: 'ISSAM SAIDI_BIS', email: 'issam.saidi@vilavi.tn' },
      { nom: 'MEZZI SAMI', email: 'sami.mezzi@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'mourad.hasnaoui@vilavi.tn',
    nom: 'Mourad Hasnaoui',
    aliases: ['MOURAD HASNAOUI', 'HASNAOUI MOURAD', 'HASNAOUI'],
    zone: 'Bizerte - Ariana - Manouba',
    budgetHabillageHt: 40000,
    budgetCadeauTtc: 55000,
    superviseurs: [
      { nom: 'ISSAM SAIDI', email: 'issam.saidi@vilavi.tn' },
      { nom: 'ZGHIDI CHOKRI_BIS', email: 'chokri.zghidi@vilavi.tn' },
      { nom: 'MEZZI SAMI_BIS', email: 'sami.mezzi@vilavi.tn' },
      { nom: 'MOURAD HASNAOUI', email: 'mourad.hasnaoui@vilavi.tn' }
    ]
  },
  {
    cdzEmail: 'walid.chaabani@vilavi.tn',
    nom: 'Walid Chaabani',
    aliases: ['WALID CHAABANI', 'CHAABANI WALID', 'MANAGER GMS (Walid Chaabani)'],
    zone: 'GMS - Réseau National',
    budgetHabillageHt: 25000,
    budgetCadeauTtc: 30000,
    superviseurs: [
      { nom: 'WALID CHAABANI', email: 'walid.chaabani@vilavi.tn' },
      { nom: 'ISSAM SAMMANI', email: 'issam.sammani@vilavi.tn' }
    ]
  }
];

export function findCdzBudget(chefName?: string): CdzBudget | undefined {
  if (!chefName) return undefined;
  const normChef = chefName.trim().toUpperCase();
  return CDZ_LIST.find((c) =>
    c.nom.toUpperCase() === normChef ||
    c.aliases.some((a) => normChef.includes(a.toUpperCase()) || a.toUpperCase().includes(normChef)) ||
    c.superviseurs?.some((s) => s.nom.toUpperCase() === normChef || normChef.includes(s.nom.toUpperCase()))
  );
}

export function getCdzByEmailOrName(str?: string): CdzBudget | undefined {
  if (!str) return undefined;
  const s = str.trim().toLowerCase();
  return CDZ_LIST.find((c) =>
    c.cdzEmail.toLowerCase() === s ||
    c.nom.toLowerCase() === s ||
    c.aliases.some((a) => a.toLowerCase() === s) ||
    c.superviseurs?.some((sup) => sup.email?.toLowerCase() === s || sup.nom.toLowerCase() === s) ||
    c.zone.toLowerCase().includes(s) ||
    s.includes(c.zone.toLowerCase())
  );
}

export const getCdzByZoneOrEmail = getCdzByEmailOrName;
