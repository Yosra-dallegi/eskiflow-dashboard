import React from 'react';
import { UserCheck, MapPin, Lock, LogOut, Wallet, Shield, Users } from 'lucide-react';
import { ActiveProfile } from '../services/cdzAuthService';

interface CdzActiveBannerProps {
  activeProfile: ActiveProfile;
  onOpenAccessModal: () => void;
  onLogoutToAdmin: () => void;
  tasksCount: number;
  frigosCount: number;
}

export const CdzActiveBanner: React.FC<CdzActiveBannerProps> = ({
  activeProfile,
  onOpenAccessModal,
  onLogoutToAdmin,
  tasksCount,
  frigosCount
}) => {
  if (activeProfile.role !== 'CDZ' || !activeProfile.cdz) return null;

  const cdz = activeProfile.cdz;
  const superviseurs = cdz.superviseurs || [];

  return (
    <div className="mb-3.5 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-3.5 sm:p-4 shadow-md border border-blue-700/50">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        {/* Left: CDZ identity & Zone */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center font-bold text-sm text-blue-200 shrink-0">
            <UserCheck className="w-5 h-5 text-sky-300" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-600/60 text-sky-200 px-2 py-0.5 rounded-full border border-blue-400/30 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                Accès CDZ (usersEQ)
              </span>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight truncate">
                {cdz.nom}
              </h2>
              <span className="text-xs font-mono text-sky-300 bg-white/10 px-2 py-0.2 rounded-full">
                {cdz.cdzEmail}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-blue-200/90 mt-0.5">
              <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="font-medium truncate">{cdz.zone}</span>
              <span className="opacity-40">·</span>
              <span className="text-[11px] text-blue-300 font-semibold">
                {tasksCount} tâche{tasksCount > 1 ? 's' : ''} équipe · {frigosCount} frigo{frigosCount > 1 ? 's' : ''} équipe
              </span>
            </div>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenAccessModal}
            className="px-2.5 py-1.5 text-xs font-semibold text-sky-100 bg-white/10 hover:bg-white/20 border border-white/15 rounded-xl transition cursor-pointer"
          >
            Changer d'email
          </button>
          <button
            type="button"
            onClick={onLogoutToAdmin}
            title="Revenir à la vue Direction Générale (Toutes les zones)"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-rose-200 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/30 rounded-xl transition cursor-pointer"
          >
            <LogOut className="w-3 h-3" />
            <span className="hidden xs:inline">Vue Totale</span>
          </button>
        </div>
      </div>

      {/* Superviseurs de l'équipe (les sup) */}
      <div className="mt-2.5 pt-2.5 border-t border-white/10 flex items-center gap-2 flex-wrap text-xs">
        <div className="flex items-center gap-1.5 text-sky-300 font-semibold shrink-0">
          <Users className="w-3.5 h-3.5 text-sky-400" />
          <span>Équipe superviseurs (les sup) :</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {superviseurs.length > 0 ? (
            superviseurs.map((sup, i) => (
              <span
                key={i}
                className="bg-blue-800/80 text-sky-100 text-[11px] font-medium px-2 py-0.5 rounded-lg border border-blue-600/60"
              >
                {sup.nom}
              </span>
            ))
          ) : (
            <span className="text-slate-300 text-xs italic">Supervision directe</span>
          )}
        </div>
      </div>

      {/* Zone Budgets Bar */}
      <div className="mt-2.5 pt-2 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
        <div className="flex items-center gap-2 bg-white/5 px-2.5 py-1.5 rounded-lg border border-white/5">
          <Wallet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <div className="min-w-0">
            <span className="text-[10px] text-slate-300 block leading-none">Budget Habillage</span>
            <span className="font-bold text-emerald-300 text-xs">
              {cdz.budgetHabillageHt.toLocaleString('fr-FR')} DT HT
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-white/5 px-2.5 py-1.5 rounded-lg border border-white/5">
          <Wallet className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <div className="min-w-0">
            <span className="text-[10px] text-slate-300 block leading-none">Budget Cadeaux</span>
            <span className="font-bold text-amber-300 text-xs">
              {cdz.budgetCadeauTtc.toLocaleString('fr-FR')} DT TTC
            </span>
          </div>
        </div>

        <div className="col-span-2 sm:col-span-1 flex items-center gap-1.5 text-[11px] text-blue-200/80 px-2 py-1 justify-end">
          <Shield className="w-3 h-3 text-sky-400 shrink-0" />
          <span>Restreint à vos superviseurs</span>
        </div>
      </div>
    </div>
  );
};
