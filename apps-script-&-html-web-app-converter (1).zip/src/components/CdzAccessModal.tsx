import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  UserCheck,
  MapPin,
  Check,
  Lock,
  Users,
  ChevronRight,
  LogOut,
  Mail,
  Upload,
  Sparkles,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { ActiveProfile, cdzAuthService } from '../services/cdzAuthService';
import { CdzBudget, TaskItem, FrigoItem } from '../types/task';
import * as XLSX from 'xlsx';

interface CdzAccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeProfile: ActiveProfile;
  onSelectProfile: (profile: ActiveProfile) => void;
  tasks: TaskItem[];
  frigos: FrigoItem[];
}

export const CdzAccessModal: React.FC<CdzAccessModalProps> = ({
  isOpen,
  onClose,
  activeProfile,
  onSelectProfile,
  tasks,
  frigos
}) => {
  const [emailInput, setEmailInput] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [rememberDevice, setRememberDevice] = useState<boolean>(true);
  const [isUploadingUsersEq, setIsUploadingUsersEq] = useState<boolean>(false);

  if (!isOpen) return null;

  const allCdz = cdzAuthService.getAllCdz();

  // Compute counts per CDZ (team data)
  const getCdzCounts = (cdz: CdzBudget) => {
    const taskCount = tasks.filter((t) => cdzAuthService.isTaskOfCdz(t, cdz)).length;
    const frigoCount = frigos.filter((f) => cdzAuthService.isFrigoOfCdz(f, cdz)).length;
    return { taskCount, frigoCount };
  };

  const handleLoginWithEmail = (emailToUse?: string) => {
    const target = emailToUse || emailInput;
    setErrorMessage(null);
    setSuccessMessage(null);

    const result = cdzAuthService.loginWithEmail(target, rememberDevice);
    if (!result.success || !result.profile) {
      setErrorMessage(result.error || 'Email non reconnu.');
      return;
    }

    onSelectProfile(result.profile);
    setSuccessMessage(
      result.profile.role === 'ADMIN'
        ? 'Connecté avec succès en tant que Direction Générale (Vue Complète).'
        : `Connecté avec succès : ${result.profile.cdz?.nom} (Équipe de ${result.profile.cdz?.superviseurs?.length || 0} superviseurs).`
    );
    setTimeout(() => {
      onClose();
    }, 900);
  };

  const handleResetToAdmin = () => {
    const profile: ActiveProfile = { role: 'ADMIN', email: 'yosra.dallegi@vilavi.tn' };
    cdzAuthService.setActiveProfile(profile);
    onSelectProfile(profile);
    onClose();
  };

  // Upload custom usersEQ sheet
  const handleUploadUsersEq = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingUsersEq(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result as ArrayBuffer;
        const wb = XLSX.read(buffer, { type: 'array' });
        const parsed = cdzAuthService.parseUsersEqWorkbook(wb);
        if (!parsed || parsed.length === 0) {
          throw new Error('Feuille "usersEQ" introuvable dans le classeur ou format d\'en-tête invalide.');
        }
        setSuccessMessage(`Succès : ${parsed.length} Chefs de Zone et leurs équipes chargés depuis la feuille usersEQ !`);
      } catch (err: any) {
        setErrorMessage(err.message || 'Erreur lors du traitement de la feuille usersEQ');
      } finally {
        setIsUploadingUsersEq(false);
        e.target.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 z-50 animate-in fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-4 sm:p-6 shadow-2xl relative border border-slate-200"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="mb-4 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              usersEQ · Accès par Email CDZ
            </span>
            {activeProfile.role === 'CDZ' && activeProfile.cdz ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                <Lock className="w-3 h-3 text-emerald-600" />
                Session active : {activeProfile.cdz.nom}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                <Users className="w-3 h-3 text-slate-500" />
                Direction Commerciale (Toutes les équipes)
              </span>
            )}
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900">
            Connexion par Email CDZ (Feuille usersEQ)
          </h2>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            Chaque Chef de Zone qui entre son email accède <strong>exclusivement à son équipe de superviseurs (les sup)</strong> et à son portefeuille de tâches et frigos.
          </p>
        </div>

        {/* Feedback Alerts */}
        {errorMessage && (
          <div className="mb-3.5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="mb-3.5 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Email Direct Input Form */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-3.5 mb-4">
          <label className="block text-xs font-bold text-slate-800 mb-1.5">
            Saisissez votre Email professionnel (CDZ / Superviseur) :
          </label>
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            <div className="relative flex-1 min-w-[200px]">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLoginWithEmail()}
                placeholder="Ex : debeghi.lotfi@vilavi.tn ou sami.ez@vilavi.tn"
                className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-blue-200 rounded-lg text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium"
              />
            </div>
            <button
              type="button"
              onClick={() => handleLoginWithEmail()}
              className="w-full sm:w-auto px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition cursor-pointer shrink-0"
            >
              Accéder à mon équipe
            </button>
          </div>

          <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-600 flex-wrap gap-2">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberDevice}
                onChange={(e) => setRememberDevice(e.target.checked)}
                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              <span>Mémoriser cet email sur ce smartphone / PC</span>
            </label>

            {/* Upload usersEQ button */}
            <div className="relative">
              <input
                type="file"
                id="usersEqUpload"
                accept=".xlsx, .xls, .csv"
                onChange={handleUploadUsersEq}
                className="hidden"
              />
              <label
                htmlFor="usersEqUpload"
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-700 hover:text-indigo-900 bg-white/80 px-2 py-0.5 rounded border border-indigo-200 cursor-pointer"
                title="Importer un fichier Excel contenant la feuille usersEQ pour synchroniser les équipes"
              >
                <Upload className="w-3 h-3 text-indigo-600" />
                <span>{isUploadingUsersEq ? 'Chargement...' : 'Mettre à jour feuille usersEQ (.xlsx)'}</span>
              </label>
            </div>
          </div>
        </div>

        {/* CDZ Profiles with their Superviseurs list */}
        <div className="space-y-2 mb-5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Chefs de Zone & Équipes de superviseurs (usersEQ) :
            </h3>
            <span className="text-[11px] text-slate-400">Cliquez pour tester l'accès direct</span>
          </div>

          <div className="grid grid-cols-1 gap-2.5 max-h-[380px] overflow-y-auto pr-1">
            {allCdz.map((cdz) => {
              const { taskCount, frigoCount } = getCdzCounts(cdz);
              const isActive =
                activeProfile.role === 'CDZ' &&
                (activeProfile.email?.toLowerCase() === cdz.cdzEmail.toLowerCase() ||
                  activeProfile.cdz?.cdzEmail.toLowerCase() === cdz.cdzEmail.toLowerCase());

              return (
                <div
                  key={cdz.cdzEmail}
                  className={`p-3 rounded-xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isActive
                      ? 'bg-blue-50/90 border-blue-300 shadow-xs ring-1 ring-blue-400'
                      : 'bg-white hover:bg-slate-50 border-slate-200 shadow-xs'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-slate-900 text-xs sm:text-sm">
                        {cdz.nom}
                      </span>
                      <span className="text-[11px] font-mono text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200">
                        {cdz.cdzEmail}
                      </span>
                      {isActive && (
                        <span className="bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" />
                          Connecté
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-slate-600 mt-0.5">
                      <MapPin className="w-3 h-3 text-blue-600 shrink-0" />
                      <span className="truncate font-medium">{cdz.zone}</span>
                    </div>

                    {/* Superviseurs list (les sup) */}
                    <div className="mt-1.5 pt-1.5 border-t border-slate-100 flex items-start gap-1.5 text-[11px]">
                      <span className="font-bold text-indigo-900 shrink-0">Superviseurs (les sup) :</span>
                      <div className="flex items-center gap-1 flex-wrap">
                        {cdz.superviseurs && cdz.superviseurs.length > 0 ? (
                          cdz.superviseurs.map((sup, idx) => (
                            <span
                              key={idx}
                              className="bg-indigo-50 text-indigo-800 text-[10px] font-semibold px-1.5 py-0.2 rounded border border-indigo-200/60"
                              title={sup.email ? `Email: ${sup.email}` : sup.nom}
                            >
                              {sup.nom}
                            </span>
                          ))
                        ) : (
                          <span className="text-slate-400 text-[10px]">Direct</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-500">
                      <span className="bg-slate-100 px-1.5 py-0.5 rounded font-medium text-slate-700">
                        {taskCount} tâche{taskCount > 1 ? 's' : ''} équipe
                      </span>
                      <span className="bg-slate-100 px-1.5 py-0.5 rounded font-medium text-slate-700">
                        {frigoCount} frigo{frigoCount > 1 ? 's' : ''} équipe
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleLoginWithEmail(cdz.cdzEmail)}
                    className={`self-end sm:self-center px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition flex items-center gap-1 cursor-pointer ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-blue-600 hover:text-white text-slate-700'
                    }`}
                  >
                    <span>{isActive ? 'Votre Équipe' : 'Connexion CDZ'}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Direction Générale / Admin Switch Option */}
        <div className="border-t border-slate-100 pt-3 flex items-center justify-between flex-wrap gap-2">
          {activeProfile.role === 'CDZ' ? (
            <button
              type="button"
              onClick={handleResetToAdmin}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-slate-500" />
              <span>Quitter le mode CDZ (Vue Direction / Toutes les équipes)</span>
            </button>
          ) : (
            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Mode Direction actif (Toutes les zones et superviseurs visibles).</span>
            </div>
          )}

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
