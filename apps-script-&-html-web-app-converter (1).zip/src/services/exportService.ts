import * as XLSX from 'xlsx';
import { TaskItem, FrigoItem } from '../types/task';

const fr = (s?: string) => s ? s.split('-').reverse().join('/') : '';
const pct = (a: number, b: number) => b ? Math.round((a * 100) / b) : 0;

export function exportTasksExcel(list: TaskItem[]) {
  if (!list.length) {
    alert('Aucune tâche à exporter avec les filtres actuels.');
    return;
  }

  const detail = list.slice().sort((a, b) => (a.echeance || '').localeCompare(b.echeance || '')).map(t => ({
    'ID tâche': t.id,
    'Code client': t.code,
    'Client': t.clientNom,
    'Chef de zone': t.chef,
    'Délégation': t.cdr,
    'Représentant': t.repr,
    'Tâche': t.titre,
    'Échéance': fr(t.echeance),
    'État': t.etat,
    'Date réalisation': fr(t.dateReal),
    'Réalisé par': t.realisePar,
    'Demandeur': t.demandeur,
    'Écart vs échéance (j)': t.ecart == null ? '' : t.ecart,
    'CA 2026': Math.round(t.ca26 || 0),
    'Inscription FID': t.inscrit ? 'Oui' : 'Non',
    'Date inscription': fr(t.dateInsc),
    'Latitude': t.lat || '',
    'Longitude': t.lng || ''
  }));

  const agg = (keyFn: (t: TaskItem) => string, label: string) => {
    const m: Record<string, { total: number; done: number; wait: number; late: number; ca: number }> = {};
    list.forEach(t => {
      const k = keyFn(t) || '—';
      if (!m[k]) m[k] = { total: 0, done: 0, wait: 0, late: 0, ca: 0 };
      m[k].total++;
      if (t.done) m[k].done++;
      else if (t.late) m[k].late++;
      else m[k].wait++;
      m[k].ca += t.ca26 || 0;
    });

    return Object.keys(m).sort((a, b) => m[b].total - m[a].total).map(k => ({
      [label]: k,
      'Total': m[k].total,
      'Terminées': m[k].done,
      'En attente': m[k].wait,
      'En retard': m[k].late,
      'Taux de réalisation (%)': pct(m[k].done, m[k].total),
      'CA 2026 clients': Math.round(m[k].ca)
    }));
  };

  const wb = XLSX.utils.book_new();
  const add = (rows: any[], name: string) => {
    if (!rows.length) return;
    const ws = XLSX.utils.json_to_sheet(rows);
    ws['!cols'] = Object.keys(rows[0]).map(k => ({ wch: Math.max(12, k.length + 2) }));
    XLSX.utils.book_append_sheet(wb, ws, name);
  };

  add(detail, 'Détail');
  add(agg(t => t.chef, 'Chef de zone'), 'Par chef de zone');
  add(agg(t => t.titre, 'Tâche'), 'Par tâche');

  const d = new Date();
  const z = (n: number) => ('0' + n).slice(-2);
  XLSX.writeFile(wb, `Taches_${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}.xlsx`);
}

export const FRZ_LIBELLES: Record<string, string> = {
  serial: 'SERIALNUMBER',
  codeClient: 'Code client',
  nomClient: 'Nom client',
  habillage: 'Habillage',
  usage: 'Usage',
  statutFrz: 'Statut FRZ',
  annee: 'Année',
  map: 'Map',
  nbFrz: 'Nb FRZ',
  datePremFact: 'Date première facture',
  dateDerFact: 'Date dernière facture',
  nbScan: 'Nb scan',
  dateDernScan: 'Date dernier scan',
  confFrzGps: 'Conf. FRZ GPS',
  gpsVisit: 'GPS visite',
  confClt: 'Conf. client',
  contrat: 'Contrat',
  date: 'Date',
  statut: 'Statut',
  classe: 'Classe',
  codeRep: 'Code représentant',
  nomRep: 'Représentant',
  superviseur: 'Superviseur',
  chefZone: 'Chef de zone',
  score: 'Score',
  risque: 'Statut risque',
  actions: 'Actions',
  impactScan: 'Impact Scan',
  impactActivation: 'Impact Activation',
  impactRythmeVente: 'Impact Rythme vente',
  impactStatut: 'Impact Statut',
  impactDetection: 'Impact Détection',
  impactGps: 'Impact GPS',
  impactContrat: 'Impact Contrat'
};

const FRZ_DATES = ['datePremFact', 'dateDerFact', 'dateDernScan', 'date'];

export function exportFrigosExcel(frigoList: FrigoItem[]) {
  if (!frigoList.length) {
    alert('Aucun frigo à exporter avec les filtres actuels.');
    return;
  }

  const cols = Object.keys(FRZ_LIBELLES);
  const rows = frigoList.map(f => {
    const o: Record<string, any> = {};
    cols.forEach(k => {
      const val = (f as any)[k];
      o[FRZ_LIBELLES[k]] = FRZ_DATES.indexOf(k) > -1 ? fr(val) : (val == null ? '' : val);
    });
    return o;
  });

  const ws = XLSX.utils.json_to_sheet(rows);
  ws['!cols'] = cols.map(k => ({ wch: Math.max(12, FRZ_LIBELLES[k].length + 2) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Frigos');

  const d = new Date();
  const z = (n: number) => ('0' + n).slice(-2);
  XLSX.writeFile(wb, `Frigos_${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}.xlsx`);
}
