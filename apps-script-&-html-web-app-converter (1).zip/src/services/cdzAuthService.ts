import { CDZ_LIST, findCdzBudget, getCdzByEmailOrName } from '../data/cdzData';
import { CdzBudget, TaskItem, FrigoItem, SupervisorItem } from '../types/task';
import * as XLSX from 'xlsx';

export type UserRole = 'ADMIN' | 'CDZ';

export interface ActiveProfile {
  role: UserRole;
  email?: string;
  cdz?: CdzBudget;
  loginTime?: string;
  isLocked?: boolean;
}

const STORAGE_KEY = 'eskiflow_active_profile_v3';
const USERSEQ_CACHE_KEY = 'eskiflow_users_eq_cache';

// Admin / Direction emails that have full access to all zones
const ADMIN_EMAILS = [
  'yosra.dallegi@vilavi.tn',
  'admin@vilavi.tn',
  'direction@vilavi.tn',
  'sofiene.gafsi@vilavi.tn'
];

export const cdzAuthService = {
  // Returns all CDZ with custom usersEQ overrides if available
  getAllCdz(): CdzBudget[] {
    try {
      const raw = localStorage.getItem(USERSEQ_CACHE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    return CDZ_LIST;
  },

  saveCustomUsersEq(list: CdzBudget[]): void {
    try {
      localStorage.setItem(USERSEQ_CACHE_KEY, JSON.stringify(list));
    } catch {}
  },

  getActiveProfile(): ActiveProfile {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as ActiveProfile;
        if (parsed.role === 'CDZ' && parsed.email) {
          const all = this.getAllCdz();
          const fresh = all.find(
            (c) => c.cdzEmail.toLowerCase() === parsed.email?.toLowerCase()
          ) || parsed.cdz;
          return { ...parsed, cdz: fresh };
        }
        return parsed;
      }
    } catch {}
    // Default to Direction / Admin so users can view everything until they log in as a specific CDZ
    return { role: 'ADMIN', email: 'yosra.dallegi@vilavi.tn' };
  },

  setActiveProfile(profile: ActiveProfile): void {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          ...profile,
          loginTime: new Date().toISOString()
        })
      );
    } catch {}
  },

  clearActiveProfile(): void {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
  },

  // Authenticate by Email directly
  loginWithEmail(rawEmail: string, remember: boolean = true): { success: boolean; profile?: ActiveProfile; error?: string } {
    const email = rawEmail.trim().toLowerCase();
    if (!email) {
      return { success: false, error: "Veuillez saisir votre adresse email professionnelle." };
    }

    // Check if Direction / Admin
    if (ADMIN_EMAILS.includes(email) || email === 'admin' || email.startsWith('admin@')) {
      const profile: ActiveProfile = {
        role: 'ADMIN',
        email,
        isLocked: remember
      };
      this.setActiveProfile(profile);
      return { success: true, profile };
    }

    // Check if matching a CDZ or a Supervisor in usersEQ
    const allCdz = this.getAllCdz();
    const matchedCdz = allCdz.find((c) => {
      if (c.cdzEmail.toLowerCase() === email) return true;
      if (c.superviseurs?.some((s) => s.email?.toLowerCase() === email)) return true;
      return false;
    }) || getCdzByEmailOrName(email);

    if (matchedCdz) {
      const profile: ActiveProfile = {
        role: 'CDZ',
        email,
        cdz: matchedCdz,
        isLocked: remember
      };
      this.setActiveProfile(profile);
      return { success: true, profile };
    }

    return {
      success: false,
      error: `L'email "${rawEmail}" n'a pas été trouvé dans la feuille usersEQ des Chefs de Zone. Veuillez vérifier l'adresse ou contacter l'administrateur.`
    };
  },

  // Check if a task belongs to this CDZ's team (superviseurs / les sup)
  isTaskOfCdz(task: TaskItem, cdz: CdzBudget): boolean {
    if (!task) return false;

    // 1. Direct chef match
    const taskChefNorm = (task.chef || '').trim().toUpperCase();
    if (taskChefNorm && taskChefNorm === cdz.nom.toUpperCase()) return true;
    if (cdz.aliases.some((a: string) => a.toUpperCase() === taskChefNorm || taskChefNorm.includes(a.toUpperCase()) || a.toUpperCase().includes(taskChefNorm))) {
      return true;
    }

    // 2. Supervisor match from usersEQ (team of supervisors)
    if (cdz.superviseurs && cdz.superviseurs.length > 0) {
      const matchSup = cdz.superviseurs.some((sup) => {
        const supNorm = sup.nom.trim().toUpperCase();
        if (taskChefNorm && (taskChefNorm === supNorm || taskChefNorm.includes(supNorm) || supNorm.includes(taskChefNorm))) {
          return true;
        }
        if (sup.email) {
          const e = sup.email.toLowerCase();
          if (task.realisePar && task.realisePar.toLowerCase() === e) return true;
          if (task.demandeur && task.demandeur.toLowerCase() === e) return true;
        }
        return false;
      });
      if (matchSup) return true;
    }

    // 3. Fallback: match via email
    const cdzEmail = cdz.cdzEmail.toLowerCase();
    if (task.realisePar && task.realisePar.toLowerCase() === cdzEmail) return true;
    if (task.demandeur && task.demandeur.toLowerCase() === cdzEmail) return true;

    // 4. Fallback: budget matching
    const matchedBudget = findCdzBudget(task.chef);
    return matchedBudget?.cdzEmail.toLowerCase() === cdzEmail;
  },

  // Check if a fridge belongs to this CDZ's team (superviseurs / les sup)
  isFrigoOfCdz(frigo: FrigoItem, cdz: CdzBudget): boolean {
    if (!frigo) return false;
    const rawChef = (frigo.chefZone || '').trim().toUpperCase();
    const rawSup = (frigo.superviseur || '').trim().toUpperCase();

    // 1. Match on CDZ name/alias
    if (rawChef && (rawChef === cdz.nom.toUpperCase() || cdz.aliases.some((a: string) => a.toUpperCase() === rawChef || rawChef.includes(a.toUpperCase()) || a.toUpperCase().includes(rawChef)))) {
      return true;
    }

    // 2. Match on Supervisor (les sup) belonging to this CDZ's team
    if (cdz.superviseurs && cdz.superviseurs.length > 0) {
      const isMySup = cdz.superviseurs.some((sup) => {
        const sNorm = sup.nom.trim().toUpperCase();
        if (rawSup && (rawSup === sNorm || rawSup.includes(sNorm) || sNorm.includes(rawSup))) return true;
        if (rawChef && (rawChef === sNorm || rawChef.includes(sNorm) || sNorm.includes(rawChef))) return true;
        return false;
      });
      if (isMySup) return true;
    }

    // 3. Fallback
    const matched = findCdzBudget(rawChef) || findCdzBudget(rawSup);
    return matched?.cdzEmail.toLowerCase() === cdz.cdzEmail.toLowerCase();
  },

  // Parse a sheet named usersEQ from any uploaded workbook
  parseUsersEqWorkbook(workbook: XLSX.WorkBook): CdzBudget[] | null {
    const sheetName = workbook.SheetNames.find((s) => {
      const l = s.toLowerCase().replace(/[\s_-]+/g, '');
      return l.includes('userseq') || l.includes('equipe') || l.includes('users');
    });

    if (!sheetName) return null;

    const sheet = workbook.Sheets[sheetName];
    if (!sheet) return null;

    const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (!rows || rows.length < 2) return null;

    const headers = (rows[0] || []).map((h) =>
      String(h || '').trim().toLowerCase().replace(/[\s\.\,\-\/\\]+/g, '_')
    );

    const kCdzEmail = headers.findIndex((h) => h.includes('email') && h.includes('cdz') || h === 'cdz' || h === 'email');
    const kCdzNom = headers.findIndex((h) => h.includes('nom') && h.includes('cdz') || h.includes('chef'));
    const kSupNom = headers.findIndex((h) => h.includes('superviseur') || h.includes('sup') || h.includes('equipe'));
    const kSupEmail = headers.findIndex((h) => h.includes('email') && (h.includes('sup') || h.includes('superviseur')));
    const kZone = headers.findIndex((h) => h.includes('zone') || h.includes('region'));
    const kHab = headers.findIndex((h) => h.includes('habillage'));
    const kCad = headers.findIndex((h) => h.includes('cadeau'));

    const map: Record<string, CdzBudget> = {};

    rows.slice(1).forEach((r) => {
      const email = String((kCdzEmail >= 0 ? r[kCdzEmail] : '') || '').trim().toLowerCase();
      if (!email || !email.includes('@')) return;

      const nom = String((kCdzNom >= 0 ? r[kCdzNom] : '') || '').trim();
      const zone = String((kZone >= 0 ? r[kZone] : '') || '').trim();
      const supNom = String((kSupNom >= 0 ? r[kSupNom] : '') || '').trim();
      const supEmail = String((kSupEmail >= 0 ? r[kSupEmail] : '') || '').trim().toLowerCase();
      const bHab = kHab >= 0 ? parseFloat(String(r[kHab]).replace(/\s/g, '').replace(',', '.')) || 0 : 0;
      const bCad = kCad >= 0 ? parseFloat(String(r[kCad]).replace(/\s/g, '').replace(',', '.')) || 0 : 0;

      if (!map[email]) {
        // Base seed if existing
        const existing = CDZ_LIST.find((c) => c.cdzEmail.toLowerCase() === email);
        map[email] = {
          cdzEmail: email,
          nom: nom || existing?.nom || email.split('@')[0],
          aliases: existing?.aliases || [nom || email.split('@')[0]],
          zone: zone || existing?.zone || 'Zone Régionale',
          budgetHabillageHt: bHab || existing?.budgetHabillageHt || 20000,
          budgetCadeauTtc: bCad || existing?.budgetCadeauTtc || 25000,
          superviseurs: []
        };
      }

      if (supNom) {
        const sups = map[email].superviseurs || [];
        if (!sups.some((s) => s.nom.toUpperCase() === supNom.toUpperCase())) {
          sups.push({ nom: supNom, email: supEmail || undefined });
        }
        map[email].superviseurs = sups;
      }
    });

    const results = Object.values(map);
    if (results.length > 0) {
      this.saveCustomUsersEq(results);
      return results;
    }
    return null;
  }
};
